﻿using System;
using System.Collections.Generic;
using Company.Logic.classes.Employees;

namespace Company.Logic.classes
{
    public class Department
    {
        public Department(string departmentName)
        {
            DepartmentName = departmentName;
            Teams = new List<Team>();
            Employees = new List<Manager>();
        }

        public string? DepartmentName { get; set; }
        public List<Team> Teams { get; set; }
        public List<Manager> Employees { get; set; }

        public void AddEmployee(Manager employee)
        {
            Employees.Add(employee);
            Console.WriteLine($"{employee.FirstName} {employee.LastName} was added to the department {DepartmentName}.");
        }

        public void AddTeam(Team team)
        {
            Teams.Add(team);
            Console.WriteLine($"Team {team.TeamName} was added to the department {DepartmentName}.");
        }

        public void DisplayDepartmentInfo()
        {
            if (Teams.Count == 0)
            {
                throw new InvalidOperationException("The department has no teams or employees.");
            }

            Console.WriteLine($"Department Information for {DepartmentName}:");

            Console.WriteLine("Teams:");
            foreach (var team in Teams)
            {
                Console.WriteLine($"- {team.TeamName}");
            }

            if (Employees.Count > 0)
            {
                Console.WriteLine("Employees:");
                foreach (var employee in Employees)
                {
                    Console.WriteLine($"- {employee.FirstName} {employee.LastName}");
                }
            }
            else
            {
                Console.WriteLine("No employees in the department.");
            }
        }
    }
}