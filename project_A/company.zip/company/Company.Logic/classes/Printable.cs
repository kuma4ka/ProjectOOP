﻿using Company.Logic.interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace Company.Logic.classes
{
    internal class PrintableClass : IPrintable
    {
        public void PrintToConsole()
        {
            Console.WriteLine();
        }

        public void PrintToFileTXT(string filePath)
        {
            throw new NotImplementedException();
        }
    }
}