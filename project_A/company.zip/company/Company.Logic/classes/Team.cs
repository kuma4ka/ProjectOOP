﻿using Company.Logic.classes.Employees;
using Company.Logic.interfaces;
using System;
using System.Collections.Generic;

namespace Company.Logic.classes
{
    public class Team : ITeam
    {
        public string TeamName { get; set; }
        public string TeamDescription { get; set; }
        public string TeamId { get; set; }
        public List<Employee> TeamMembers { get; } = new();

        public Team(string teamName, int teamId)
        {
            TeamName = teamName;
            TeamId = teamId.ToString();
        }

        public void AddTeamMember(Employee employee)
        {
            TeamMembers.Add(employee);
            Console.WriteLine($"{employee.FirstName} {employee.LastName} was added to the team {TeamName}.");
        }

        public void DisplayTeamInfo()
        {
            Console.WriteLine($"Team Information for Team {TeamName} (ID: {TeamId}):");
            Console.WriteLine($"Description: {TeamDescription}");
            Console.WriteLine("Team Members:");

            foreach (var member in TeamMembers)
            {
                Console.WriteLine($"- {member.FirstName} {member.LastName}");
            }
        }
        public void DisplayEmployeeInfo(Employee employee)
        {
            Console.WriteLine($"- {employee.FirstName} {employee.LastName}, ID: {employee.Id}, Role: {employee.Role}, Salary: {employee.Salary:C}");
        }

        public void RemoveTeamMember(Employee employee)
        {
            if (TeamMembers.Contains(employee))
            {
                TeamMembers.Remove(employee);
                Console.WriteLine($"{employee.FirstName} {employee.LastName} was removed from the team {TeamName}.");
            }
            else
            {
                Console.WriteLine($"{employee.FirstName} {employee.LastName} is not a member of the team {TeamName}.");
            }
        }
    }
}