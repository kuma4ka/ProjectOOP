﻿using Company.Logic.enums;
using Company.Logic.interfaces;
using System;
using System.IO;

namespace Company.Logic.classes.Employees
{
    public class Manager : Employee
    {
        public override string FirstName { get; set; }
        public override string LastName { get; set; }
        public override int Id { get; set; }
        public override Role Role { get; set; }
        public override int Salary { get; set; }
        public string Department { get; set; }

        public Manager(string firstName, string lastName, int id, Role role, int salary, string department)
        {
            FirstName = firstName;
            LastName = lastName;
            Id = id;
            Role = role;
            Salary = salary;
            Department = department;
        }

        public override void DisplayInfo()
        {
            Console.WriteLine($"Manager ID: {Id}");
            Console.WriteLine($"Name: {FirstName} {LastName}");
            Console.WriteLine($"Role: {Role}");
            Console.WriteLine($"Salary: {Salary:C}");
            Console.WriteLine($"Department: {Department}");
        }

        public override object Clone()
        {
            return MemberwiseClone();
        }

        public override void PrintToConsole()
        {
            throw new NotImplementedException();
        }

        public override void PrintToFileTXT(string filePath)
        {
            throw new NotImplementedException();
        }
    }
}